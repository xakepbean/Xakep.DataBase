#if (_MSC_VER > 1200)
#define HAVE_LONG_LONG_INT_64 1
#define ENABLE_THREAD_SAFETY 1
#endif
